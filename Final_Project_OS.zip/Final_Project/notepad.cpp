#include <cstdlib>
#include <iostream>
#include <unistd.h>

using namespace std;

int main() {
    char choice;
    cout << "notepad started (PID: " << getpid() << ")\n";
    while (true)
    {
        cout << "Do you want to use notepade? (q to quit,m to minimize and any other key to continue): ";
        cin >> choice;

        if (choice == 'q' || choice == 'Q') {
            break;
        }

        if (choice == 'm' || choice == 'M') {
            cout << "minimizing notepad PID ( " << getpid() << "), you can resume later.\n";
            continue;
        }
        string fileName;
        string filePath = "/home/meerab/Downloads/mini_OS_project/mini_OS/notepad.txt"; //change this to your desired directory

        cout << "Enter the file name: ";
        cin >> fileName;

        string command = "gedit " + filePath + fileName;
        system(command.c_str());
    }

    return 0;
}
