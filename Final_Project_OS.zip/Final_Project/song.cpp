#include <iostream>
#include <cstdlib>

using namespace std;

int main() {
    string filename;
    cout << "Enter the full name of the file (e.g., song.mp4): ";
    cin >> filename;
    // Command to play only the audio of the video file
    string command = "vlc --no-video " + filename + " --play-and-exit";
    system(command.c_str());
    return 0;
}

