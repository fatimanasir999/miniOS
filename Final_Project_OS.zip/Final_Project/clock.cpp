#include <cstdlib>
#include <iostream>

using namespace std;

int main() {
    system("gnome-clocks");
    return 0;
}

